const audio = document.getElementById("favsong");
function play() {
   audio.play()
};
function pause() {
   audio.pause()
};
